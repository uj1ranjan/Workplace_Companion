import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Function to load WebChat script
const loadWebChatScript = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Check if WebChat is already loaded
    if ((window as any).WebChat) {
      console.log('WebChat already available');
      resolve();
      return;
    }

    console.log('Loading WebChat script...');
    const script = document.createElement('script');
    script.src = 'https://cdn.botframework.com/botframework-webchat/latest/webchat.js';
    script.crossOrigin = 'anonymous';

    script.onload = () => {
      console.log('✅ WebChat script loaded successfully');
      // Give it a moment to initialize
      setTimeout(() => {
        if ((window as any).WebChat) {
          console.log('✅ WebChat API confirmed available');
          resolve();
        } else {
          console.error('❌ WebChat API not available after loading');
          reject(new Error('WebChat API not available'));
        }
      }, 100);
    };

    script.onerror = (error) => {
      console.error('❌ Failed to load WebChat script:', error);
      reject(new Error('WebChat script loading failed'));
    };

    // Add to head
    document.head.appendChild(script);
  });
};

// Initialize the application
const initializeApp = async () => {
  console.log('🚀 Starting application initialization...');

  try {
    // Try to load WebChat (but don't block the app if it fails)
    await loadWebChatScript();
    console.log('✅ WebChat ready for use');
  } catch (error) {
    console.warn('⚠️ WebChat failed to load, app will continue without it:', error);
  }

  // Always render the React app
  console.log('🎨 Rendering React application...');
  const root = createRoot(document.getElementById("root")!);
  root.render(<App />);

  console.log('✅ Application initialized successfully');
};

// Start the application
initializeApp();