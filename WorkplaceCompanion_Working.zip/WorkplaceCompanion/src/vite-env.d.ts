/// <reference types="vite/client" />

// WebChat type definitions
declare global {
  interface Window {
    WebChat?: {
      createDirectLine: (options: { token: string }) => any;
      createStore: (options?: any, middleware?: any) => any;
      renderWebChat: (options: any, element: HTMLElement) => void;
    };
  }
}

// Export empty object to make this a module
export {};