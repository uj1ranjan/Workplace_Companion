import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChatInterface } from '@/components/ChatInterface';
import { QuickActions } from '@/components/QuickActions';
import { Bot, Clock, Users, TrendingUp, Zap } from 'lucide-react';
import heroImage from '@/assets/it-hero-image.jpg';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header - COMPRESSED */}
      <header className="border-b bg-card shadow-soft">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">TCS Workplace Companion</h1>
                <p className="text-sm text-muted-foreground">Your intelligent IT helpdesk assistant</p>
                <div>
                  <Badge variant="outline" className="border-success text-success">
                    <div className="w-2 h-2 bg-success rounded-full mr-2"></div>
                    System Healthy
                  </Badge>
                  <Badge variant="secondary">
                    24/7 Available
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section - COMPRESSED */}
      <section className="py-8 bg-gradient-secondary">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-4 text-foreground">
                Get IT Help <span className="text-primary">Instantly</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Your go to agent to help you with any workplace related tasks from getting you curated knowledge to handling tickets on our behalf, providing alerts and performing self help requests
              </p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">24/7</div>
                  <div className="text-sm text-muted-foreground">Always Available</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">&lt;1min</div>
                  <div className="text-sm text-muted-foreground">Average Response</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">97%</div>
                  <div className="text-sm text-muted-foreground">Resolution Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">550+</div>
                  <div className="text-sm text-muted-foreground">Issues Resolved</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <img 
                src={heroImage} 
                alt="IT Support and Technology" 
                className="rounded-lg shadow-large w-full"
              />
              <div className="absolute inset-0 bg-gradient-primary/10 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content - ZERO GAPS */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chat Interface - IMMEDIATE START WITH ZERO SPACING */}
          <div className="lg:col-span-2">
            {/* ZERO MARGIN, ZERO PADDING TITLE */}
            <div className="mb-2">
              <h3 className="text-xl font-semibold mb-1 text-foreground">Start a Conversation</h3>
              <p className="text-sm text-muted-foreground">
                Describe your IT issue and get instant help from our intelligent assistant.
              </p>
            </div>
            {/* CHAT STARTS IMMEDIATELY HERE - ABSOLUTE ZERO GAPS */}
            <div style={{ margin: 0, padding: 0, lineHeight: 1 }}>
              <ChatInterface />
            </div>
          </div>

          {/* Sidebar - COMPRESSED */}
          <div className="space-y-6">
            {/* System Status Card */}
            <Card className="p-4 shadow-medium">
              <h4 className="font-semibold mb-3 text-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                System Status
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Network</span>
                  <Badge variant="outline" className="border-success text-success text-xs">
                    <div className="w-2 h-2 bg-success rounded-full mr-1"></div>
                    Optimal
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Email Services</span>
                  <Badge variant="outline" className="border-success text-success text-xs">
                    <div className="w-2 h-2 bg-success rounded-full mr-1"></div>
                    Online
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">File Servers</span>
                  <Badge variant="outline" className="border-warning text-warning text-xs">
                    <div className="w-2 h-2 bg-warning rounded-full mr-1"></div>
                    Maintenance
                  </Badge>
                </div>
              </div>
            </Card>

            {/* Recent Activity Card */}
            <Card className="p-4 shadow-medium">
              <h4 className="font-semibold mb-3 text-foreground flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                Recent Activity
              </h4>
              <div className="space-y-2">
                <div className="text-sm">
                  <div className="font-medium text-foreground">Password reset completed</div>
                  <div className="text-xs text-muted-foreground">2 minutes ago</div>
                </div>
                <div className="text-sm">
                  <div className="font-medium text-foreground">Software update deployed</div>
                  <div className="text-xs text-muted-foreground">1 hour ago</div>
                </div>
                <div className="text-sm">
                  <div className="font-medium text-foreground">Network optimization</div>
                  <div className="text-xs text-muted-foreground">3 hours ago</div>
                </div>
              </div>
            </Card>

            {/* Support Team Stats Card */}
            <Card className="p-4 shadow-medium">
              <h4 className="font-semibold mb-3 text-foreground flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                Support Team
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Available Agents</span>
                  <Badge variant="secondary" className="text-xs">3 Online</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Queue Length</span>
                  <Badge variant="outline" className="border-success text-success text-xs">0 Waiting</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Avg. Response</span>
                  <Badge variant="outline" className="border-info text-info text-xs">
                    <Zap className="w-3 h-3 mr-1" />
                    Instant
                  </Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Quick Actions Section - COMPRESSED */}
        <div className="mt-8">
          <QuickActions />
        </div>
      </main>

      {/* Footer - COMPRESSED */}
      <footer className="border-t bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 TCS Workplace Companion</p>
            <p className="mt-2">You can contact Global Helpdesk, Email :<a href="mailto: Global.Helpdesk@tcs.com"> Global.Helpdesk@tcs.com</a> Contact number : <a href="tel:18002576563">18002576563</a> for India</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;