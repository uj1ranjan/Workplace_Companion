// msalConfig.ts
import { PublicClientApplication, LogLevel } from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: "0ef3c3eb-4bec-4158-aea1-a487840cc336",
    authority: "https://login.microsoftonline.com/3c8ea0e4-127c-4a02-ac65-58830e4ac608",
    redirectUri: "http://localhost:8080/",
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level: LogLevel, message: string, containsPii: boolean) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

// Login request scopes - add bot-specific scopes here
export const loginRequest = {
  scopes: ["User.Read", "openid", "profile"],
};

// Silent request for token refresh
export const silentRequest = {
  scopes: ["User.Read"],
  account: undefined as any, // Will be set dynamically
};

export const clientApplication = new PublicClientApplication(msalConfig);

// Initialize MSAL with better error handling
const initializeMSAL = async () => {
  try {
    await clientApplication.initialize();
    console.log("MSAL initialized successfully");

    // Handle redirect promise
    const response = await clientApplication.handleRedirectPromise();
    if (response) {
      console.log("Redirect response received:", response);
    }
  } catch (error) {
    console.error("MSAL initialization failed:", error);
  }
};

// Initialize immediately
initializeMSAL();

// Helper function to get current user account
export const getCurrentAccount = () => {
  const accounts = clientApplication.getAllAccounts();
  return accounts.length > 0 ? accounts[0] : null;
};

// Helper function for silent token acquisition
export const acquireTokenSilently = async (scopes: string[]) => {
  const account = getCurrentAccount();
  if (!account) {
    throw new Error("No account found");
  }

  const silentRequest = {
    scopes,
    account,
  };

  try {
    const response = await clientApplication.acquireTokenSilent(silentRequest);
    return response.accessToken;
  } catch (error) {
    console.error("Silent token acquisition failed:", error);
    throw error;
  }
};