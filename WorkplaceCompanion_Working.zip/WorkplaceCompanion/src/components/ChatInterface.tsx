import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Bot, Loader2, AlertCircle, LogIn, LogOut, RefreshCw, Wifi } from 'lucide-react';
import { clientApplication } from "../msalConfig";
import './ChatComponent.css';

interface UserAccount {
  localAccountId: string;
  name?: string;
  username: string;
}

export const ChatInterface = () => {
  const [webChatLoaded, setWebChatLoaded] = useState(false);
  const [webChatError, setWebChatError] = useState('');
  const [tokenLoading, setTokenLoading] = useState(false);
  const [user, setUser] = useState<UserAccount | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);
  const [webChatKey, setWebChatKey] = useState(0);
  const webChatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkWebChat = () => {
      if ((window as any).WebChat) {
        setWebChatLoaded(true);
        console.log('✅ WebChat scripts loaded successfully');
      }
    };

    checkWebChat();
    const interval = setInterval(checkWebChat, 500);
    setTimeout(() => clearInterval(interval), 15000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    try {
      const accounts = clientApplication.getAllAccounts();
      if (accounts.length > 0) {
        const account = accounts[0];
        setUser({
          localAccountId: account.localAccountId,
          name: account.name,
          username: account.username
        });
        console.log('Existing user session found:', account.name);
      }
    } catch (error) {
      console.error('Error checking existing session:', error);
    }
  };

  const forceWebChatRecreation = () => {
    console.log('🔄 Forcing WebChat recreation...');
    setWebChatKey(prev => prev + 1);
    setWebChatError('');
    setTokenLoading(false);

    if (webChatContainerRef.current) {
      webChatContainerRef.current.innerHTML = '';
    }

    const existingContainers = document.querySelectorAll('[id^="webchat-root"]');
    existingContainers.forEach(container => container.remove());
  };

  const handleLogin = async () => {
    setLoginLoading(true);
    try {
      const loginRequest = {
        scopes: ["User.Read", "openid", "profile"],
        prompt: "select_account"
      };

      const response = await clientApplication.loginPopup(loginRequest);

      if (response.account) {
        setUser({
          localAccountId: response.account.localAccountId,
          name: response.account.name,
          username: response.account.username
        });
        console.log('Login successful:', response.account.name);

        forceWebChatRecreation();

        setTimeout(() => {
          initializeWebChat();
        }, 1000);
      }
    } catch (error) {
      console.error('Login failed:', error);
      setWebChatError('Login failed. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await clientApplication.logoutPopup();
      setUser(null);
      console.log('Logout successful');

      forceWebChatRecreation();

      setTimeout(() => {
        initializeWebChat();
      }, 1000);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const getOAuthCardResourceUri = (activity: any) => {
    if (
      activity &&
      activity.attachments &&
      activity.attachments[0] &&
      activity.attachments[0].contentType === "application/vnd.microsoft.card.oauth" &&
      activity.attachments[0].content.tokenExchangeResource
    ) {
      return activity.attachments[0].content.tokenExchangeResource.uri;
    }
  };

  const exchangeTokenAsync = async (resourceUri: string) => {
    if (user) {
      try {
        const requestObj = { scopes: [resourceUri], account: clientApplication.getAllAccounts()[0] };
        const tokenResponse = await clientApplication.acquireTokenSilent(requestObj);
        return tokenResponse.accessToken;
      } catch (error) {
        console.error("Token exchange failed", error);
        return null;
      }
    }
    return null;
  };

  const initializeWebChat = async () => {
    if (!webChatLoaded) {
      setWebChatError('WebChat scripts are still loading. Please wait...');
      return;
    }

    setTokenLoading(true);
    setWebChatError('');

    try {
      console.log(`🔄 Initializing WebChat (Key: ${webChatKey}) - SIGN IN BUTTON PROTECTED + FULL WIDTH...`);

      const response = await fetch("https://4e719def09e4e0ce82787973a70423.0a.environment.api.powerplatform.com/powervirtualagents/botsbyschema/cr61c_agent1_tpLqi8/directline/token?api-version=2022-03-01-preview");

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const { token } = await response.json();

      if (!token) {
        throw new Error('No token received from server');
      }

      console.log('✅ Direct Line token obtained');

      const userId = user
        ? `Your-customized-prefix${user.localAccountId}-${webChatKey}`.substr(0, 64)
        : (Math.random().toString() + Date.now().toString() + webChatKey).substr(0, 64);

      const directLine = (window as any).WebChat.createDirectLine({ 
        token,
        watermark: ''
      });

      const store = (window as any).WebChat.createStore({}, ({ dispatch }: any) => (next: any) => (action: any) => {
        const { type } = action;

        if (type === "DIRECT_LINE/CONNECT_FULFILLED") {
          console.log('✅ DirectLine connection established (Fresh session)');

          dispatch({
            type: "WEB_CHAT/SEND_EVENT",
            payload: {
              name: "startConversation",
              type: "event",
              value: { 
                text: "hello",
                user: {
                  id: userId,
                  name: user?.name || user?.username || "Anonymous User",
                  email: user?.username || "anonymous@example.com"
                }
              },
            },
          });
        }

        if (type === "DIRECT_LINE/INCOMING_ACTIVITY") {
          const activity = action.payload.activity;

          console.log('📨 INCOMING MESSAGE:', {
            type: activity.type,
            text: activity.text?.substring(0, 100),
            hasAttachments: !!activity.attachments?.length,
            timestamp: new Date().toLocaleTimeString()
          });

          // PRECISE: Block ONLY specific login activities (not all buttons!)
          if (activity.text && 
              (activity.text.trim() === 'To continue, please login' ||
               activity.text.trim() === 'Please login to continue' ||
               activity.text.toLowerCase().includes('to continue, please login'))) {
            console.log('🚫 BLOCKED specific login dialog:', activity.text);
            return;
          }

          // PRECISE: Block ONLY OAuth cards (not Sign In buttons!)
          if (activity.attachments && activity.attachments.length > 0) {
            const attachment = activity.attachments[0];
            if (attachment.contentType === "application/vnd.microsoft.card.oauth") {
              console.log('🚫 BLOCKED OAuth login card (not Sign In button)');

              let resourceUri = getOAuthCardResourceUri(activity);
              if (resourceUri && user) {
                console.log('🔐 Handling OAuth silently in background...');
                exchangeTokenAsync(resourceUri).then((token) => {
                  if (token) {
                    directLine
                      .postActivity({
                        type: "invoke",
                        name: "signin/tokenExchange",
                        value: {
                          id: attachment.content.tokenExchangeResource.id,
                          connectionName: attachment.content.connectionName,
                          token,
                        },
                        from: {
                          id: userId,
                          name: user.name || user.username,
                          role: "user",
                        },
                      })
                      .subscribe();

                    console.log('✅ OAuth token exchange completed silently');
                  }
                }).catch(error => {
                  console.error('OAuth error:', error);
                });
              }

              return;
            }
          }
        }

        return next(action);
      });

      const styleOptions = {
        hideUploadButton: false,
        avatarSize: 40,
        botAvatarImage: '',
        botAvatarInitials: 'TC',
        userAvatarImage: '',
        userAvatarInitials: user?.name ? user.name.charAt(0).toUpperCase() : 'U',
        bubbleFromUserBackground: '#767e7eff',
        bubbleBackground: '#e4e4fc',
        suggestedActionBackground: '#E6E6E6',
        suggestedActionBorderColor: '#5B5BE8',
        suggestedActionTextColor: '#5B5BE8',
        sendBoxButtonColor: '#5B5BE8',
        rootHeight: '100%',
        rootWidth: '100%',

        // CRITICAL: FULL WIDTH MESSAGES
        bubbleMaxWidth: '98%',
        bubbleMinWidth: '200px',
        messageActivityWordBreak: 'break-word',
        paddingRegular: 16,
        spacingHorizontal: 12,
        marginTopDefault: 8,
        marginBottomDefault: 8
      };

      const containerId = `webchat-root-${webChatKey}`;

      const existingContainers = document.querySelectorAll('[id^="webchat-root"]');
      existingContainers.forEach(container => {
        if (container.id !== containerId) {
          container.remove();
        }
      });

      let webchatElement = document.getElementById(containerId);

      if (!webchatElement) {
        const parentElement = document.querySelector('[data-webchat-container]');
        if (parentElement) {
          webchatElement = document.createElement('div');
          webchatElement.id = containerId;
          webchatElement.style.cssText = `
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            position: relative;
            background-color: white;
            overflow: hidden;
          `;
          parentElement.appendChild(webchatElement);
          console.log(`✅ Created fresh WebChat container: ${containerId}`);
        }
      }

      if (!webchatElement) {
        throw new Error('Could not create WebChat container');
      }

      webchatElement.innerHTML = '';

      console.log('🎨 Rendering WebChat with PROTECTED Sign In button + FULL WIDTH messages...');

      (window as any).WebChat.renderWebChat(
        {
          directLine,
          store,
          userID: userId,
          username: user?.name || user?.username || 'Anonymous User',
          styleOptions,
        },
        webchatElement
      );

      setTimeout(() => {
        console.log('🧹 Applying PRECISE cleanup (preserving Sign In buttons)...');

        // PRECISE CLEANUP: Only remove specific login elements, NOT Sign In buttons
        const preciseCleanup = () => {
          // Remove ONLY specific login text elements
          const textElements = document.querySelectorAll('p, div, span');
          textElements.forEach(element => {
            const text = element.textContent?.trim() || '';
            // ONLY remove very specific login prompts
            if (text === 'To continue, please login' || 
                text === 'Please login to continue' ||
                (text.includes('continue, please login') && text.length < 100)) {
              console.log('🚫 PRECISE CLEANUP: Removing login prompt:', text);
              element.remove();
            }
          });

          // Remove OAuth cards by specific content type ONLY
          const oauthElements = document.querySelectorAll('[class*="adaptiveCard"]');
          oauthElements.forEach(element => {
            const cardText = element.textContent?.toLowerCase() || '';
            if (cardText.includes('continue, please') && cardText.includes('login')) {
              console.log('🚫 PRECISE CLEANUP: Removing OAuth card');
              element.remove();
            }
          });

          // ✅ PRESERVE: Do NOT remove buttons with "Sign In" text from header
          // ✅ PRESERVE: Do NOT remove elements with "Connected" or "Authenticated"
        };

        // Apply FULL WIDTH styling to messages
        const applyFullWidthStyling = () => {
          const messageElements = document.querySelectorAll('[role="listitem"]');
          console.log(`🔧 Applying full width to ${messageElements.length} messages...`);

          messageElements.forEach((element, index) => {
            const messageEl = element as HTMLElement;

            // CRITICAL: Full width for ALL messages
            messageEl.style.cssText = `
              display: block !important;
              visibility: visible !important;
              opacity: 1 !important;
              width: 100% !important;
              max-width: 98% !important;
              min-width: 200px !important;
              margin: 8px 0 !important;
              position: relative !important;
              box-sizing: border-box !important;
              overflow: visible !important;
            `;

            // Style the bubble content for maximum width
            const bubbles = messageEl.querySelectorAll('[class*="bubble"], [class*="message"], [class*="activity"]');
            bubbles.forEach(bubble => {
              const bubbleEl = bubble as HTMLElement;
              bubbleEl.style.cssText = `
                width: 100% !important;
                max-width: 98% !important;
                min-width: 200px !important;
                padding: 16px 20px !important;
                margin: 0 !important;
                box-sizing: border-box !important;
                word-wrap: break-word !important;
                white-space: pre-wrap !important;
                line-height: 1.6 !important;
                font-size: 15px !important;
                border-radius: 12px !important;
              `;
            });

            // Style text content for full width
            const textElements = messageEl.querySelectorAll('[role="text"], p, span');
            textElements.forEach(text => {
              const textEl = text as HTMLElement;
              textEl.style.cssText = `
                width: 100% !important;
                max-width: 100% !important;
                display: block !important;
                visibility: visible !important;
                opacity: 1 !important;
                font-size: 15px !important;
                line-height: 1.6 !important;
                word-wrap: break-word !important;
                white-space: pre-wrap !important;
              `;
            });

            console.log(`✅ Applied full-width styling to message ${index + 1}`);
          });

          // Fix transcript container for full width
          const transcriptElements = document.querySelectorAll('[data-testid="transcript"]');
          transcriptElements.forEach(transcript => {
            const transcriptEl = transcript as HTMLElement;
            transcriptEl.style.cssText = `
              width: 100% !important;
              height: 100% !important;
              padding: 12px 16px !important;
              box-sizing: border-box !important;
              overflow-y: auto !important;
              overflow-x: hidden !important;
            `;
          });

          console.log('✅ Applied full-width transcript styling');
        };

        // Apply cleanup and styling immediately
        preciseCleanup();
        applyFullWidthStyling();

        // MODERATE monitoring (not aggressive) - preserve Sign In buttons
        let cleanupCount = 0;
        const cleanupInterval = setInterval(() => {
          cleanupCount++;
          preciseCleanup(); // Only remove specific login prompts
          applyFullWidthStyling(); // Maintain full width

          if (cleanupCount >= 10) { // Reduced from 15 to 10
            clearInterval(cleanupInterval);
            console.log('✅ Precise cleanup completed - Sign In buttons preserved, full width applied');
          }
        }, 1000);

      }, 2000);

      console.log('🎉 SUCCESS: WebChat with PROTECTED Sign In + FULL WIDTH messages!');

    } catch (error) {
      console.error('❌ Error initializing WebChat:', error);
      setWebChatError(`WebChat Setup Failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setTokenLoading(false);
    }
  };

  useEffect(() => {
    if (webChatLoaded && !tokenLoading) {
      setTimeout(() => {
        initializeWebChat();
      }, 500);
    }
  }, [webChatLoaded, user, webChatKey]);

  const retryWebChat = () => {
    forceWebChatRecreation();
    setTimeout(() => {
      initializeWebChat();
    }, 500);
  };

  const UserProfile = ({ user }: { user: UserAccount }) => {
    const initials = user.name 
      ? user.name.split(' ').map(n => n[0]).join('').toUpperCase() 
      : user.username.charAt(0).toUpperCase();

    return (
      <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 rounded-lg border border-blue-200">
        <Avatar className="w-6 h-6">
          <AvatarImage src={`https://graph.microsoft.com/v1.0/users/${user.username}/photo/$value`} />
          <AvatarFallback className="bg-blue-500 text-white text-xs">
            {initials}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">{user.name || user.username}</p>
          <p className="text-xs text-green-600">✅ Authenticated</p>
        </div>
        <Button onClick={handleLogout} variant="ghost" size="sm" className="h-6 w-6 p-0">
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    );
  };

  return (
    <div className="w-full h-[600px] flex flex-col border border-gray-200 rounded-lg shadow-lg bg-white">
      {/* Header with PROTECTED Sign In button */}
      <div className="flex justify-between items-center px-6 py-4 border-b bg-gray-50 rounded-t-lg">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center shadow-md">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-gray-800">TCS Workplace Companion</h1>
            <p className="text-sm text-gray-600">WebChat Mode • Ready to help</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 bg-green-100 text-green-800 rounded-full">
            <Wifi className="w-4 h-4" />
            <span className="text-sm">Connected</span>
          </div>
          {user ? (
            <UserProfile user={user} />
          ) : (
            <Button 
              onClick={handleLogin} 
              variant="outline" 
              size="sm" 
              disabled={loginLoading}
              className="text-sm px-4 py-2 h-10 bg-white hover:bg-gray-50 border-gray-300"
              style={{
                zIndex: 9999,
                position: 'relative',
                display: 'flex',
                alignItems: 'center',
                gap: '8px'
              }}
            >
              {loginLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Signing In...
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  Sign In
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* WebChat Container with Key for Force Recreation */}
      <div 
        key={webChatKey}
        data-webchat-container
        className="flex-1 bg-white relative overflow-hidden"
        style={{ height: 'calc(600px - 88px)' }}
      >
        {!webChatLoaded ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="bg-blue-50 rounded-full p-6 mb-6">
              <Bot className="w-12 h-12 text-blue-500" />
            </div>
            <Loader2 className="w-8 h-8 animate-spin mb-4 text-blue-500" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Loading WebChat</h2>
            <p className="text-sm text-gray-600 max-w-md">
              Initializing your AI assistant...
            </p>
          </div>
        ) : tokenLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="bg-green-50 rounded-full p-6 mb-6">
              <Bot className="w-12 h-12 text-green-500" />
            </div>
            <Loader2 className="w-8 h-8 animate-spin mb-4 text-green-500" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Connecting to NOVA MAX</h2>
            <p className="text-sm text-gray-600 max-w-md mb-4">
              Establishing fresh connection...
            </p>
            {user && (
              <div className="flex items-center gap-2 px-4 py-2 bg-green-100 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-green-700 font-medium">{user.name || user.username}</span>
              </div>
            )}
          </div>
        ) : webChatError ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="bg-red-50 rounded-full p-6 mb-6">
              <AlertCircle className="w-12 h-12 text-red-500" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Connection Issue</h2>
            <p className="text-sm text-gray-600 mb-6 max-w-md">
              Unable to connect to NOVA MAX. Please try again.
            </p>
            <div className="bg-gray-50 p-4 rounded-lg text-xs text-left mb-6 max-w-lg max-h-40 overflow-y-auto">
              <pre className="whitespace-pre-wrap text-gray-700">{webChatError}</pre>
            </div>
            <Button onClick={retryWebChat} variant="outline" size="lg">
              <RefreshCw className="w-5 h-5 mr-2" />
              Retry Connection
            </Button>
          </div>
        ) : (
          <div 
            ref={webChatContainerRef}
            className="w-full h-full"
          />
        )}
      </div>
    </div>
  );
};

export default ChatInterface;