import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Lock, 
  Download, 
  Wifi, 
  Mail, 
  Printer, 
  Monitor, 
  Shield, 
  HardDrive,
  Phone,
  Wrench,
  Laptop,
  DoorOpen
} from 'lucide-react';

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: 'security' | 'hardware' | 'software' | 'network';
  urgency: 'low' | 'medium' | 'high';
}

const quickActions: QuickAction[] = [
  {
    id: '1',
    title: 'Password Reset',
    description: 'Reset your domain or application password',
    icon: <Lock className="w-5 h-5" />,
    category: 'security',
    urgency: 'high',
  },
  {
    id: '2',
    title: 'Software Installation',
    description: 'New software installation request ',
    icon: <Download className="w-5 h-5" />,
    category: 'software',
    urgency: 'medium',
  },
  {
    id: '3',
    title: 'Find meeting rooms',
    description: 'Check meeting room availability',
    icon: <DoorOpen className="w-5 h-5" />,
    category: 'network',
    urgency: 'high',
  },
  {
    id: '4',
    title: 'Create Sharepoint site',
    description: 'Configure sharepoint site and access',
    icon: <Mail className="w-5 h-5" />,
    category: 'software',
    urgency: 'medium',
  },
  {
    id: '5',
    title: 'New Laptop Request',
    description: 'Need new Laptop or replacement device',
    icon: <Laptop className="w-5 h-5" />,
    category: 'hardware',
    urgency: 'medium',
  },
  {
    id: '6',
    title: 'Device Slowness Problems',
    description: 'Slowness troubleshooting on device',
    icon: <Monitor className="w-5 h-5" />,
    category: 'hardware',
    urgency: 'low',
  },
  {
    id: '7',
    title: 'Security Concerns',
    description: 'Report suspicious activity or malware',
    icon: <Shield className="w-5 h-5" />,
    category: 'security',
    urgency: 'high',
  },
  {
    id: '8',
    title: 'Storage Issues',
    description: 'Disk cleanup and remediation',
    icon: <HardDrive className="w-5 h-5" />,
    category: 'hardware',
    urgency: 'medium',
  },
];

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'security': return 'bg-destructive/10 text-destructive border-destructive/20';
    case 'hardware': return 'bg-warning/10 text-warning border-warning/20';
    case 'software': return 'bg-info/10 text-info border-info/20';
    case 'network': return 'bg-success/10 text-success border-success/20';
    default: return 'bg-secondary text-secondary-foreground';
  }
};

const getUrgencyColor = (urgency: string) => {
  switch (urgency) {
    case 'high': return 'bg-destructive text-destructive-foreground';
    case 'medium': return 'bg-warning text-warning-foreground';
    case 'low': return 'bg-success text-success-foreground';
    default: return 'bg-secondary text-secondary-foreground';
  }
};

export const QuickActions = () => {
  const handleActionClick = (action: QuickAction) => {
    // In a real implementation, this would trigger the chat with a pre-filled message
    console.log('Action clicked:', action.title);
  };

  return (
    <Card className="p-6 shadow-medium">
      <div className="flex items-center gap-3 mb-6">
        <Wrench className="w-6 h-6 text-primary" />
        <div>
          <h2 className="text-xl font-semibold text-foreground">Quick Actions</h2>
          <p className="text-sm text-muted-foreground">Get help with common IT issues</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Button
            key={action.id}
            variant="outline"
            className="h-auto p-4 flex flex-col items-start text-left hover:shadow-soft transition-all duration-200 hover:scale-[1.02] hover:bg-secondary/50"
            onClick={() => handleActionClick(action)}
          >
            <div className="flex items-center justify-between w-full mb-3">
              <div className={`p-2 rounded-lg ${getCategoryColor(action.category)}`}>
                {action.icon}
              </div>
              <Badge 
                variant="secondary" 
                className={`text-xs ${getUrgencyColor(action.urgency)}`}
              >
                {action.urgency}
              </Badge>
            </div>
            <div className="w-full">
              <h3 className="font-medium text-sm mb-1 text-foreground">{action.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {action.description}
              </p>
            </div>
          </Button>
        ))}
      </div>

      <div className="mt-6 p-4 bg-secondary/30 rounded-lg border border-dashed border-border">
        <div className="flex items-center gap-2 mb-2">
          <Phone className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-foreground">Need immediate help?</span>
        </div>
        <p className="text-xs text-muted-foreground">
          For urgent issues, call our IT helpdesk at <span className="font-medium text-primary">ext. 18002576563</span> or 
          use the chat to connect with a live agent.
        </p>
      </div>
    </Card>
  );
};