import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChatInterface } from '@/components/ChatInterface';
import { QuickActions } from '@/components/QuickActions';
import { Bot, Clock, Users, TrendingUp, Zap } from 'lucide-react';
import heroImage from '@/assets/it-hero-image.jpg';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-soft">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">TCS Workplace Companion</h1>
                <p className="text-sm text-muted-foreground">Your intelligent IT helpdesk assistant</p>
                <div>
                  <Badge variant="outline" className="border-success text-success">
                    <div className="w-2 h-2 bg-success rounded-full mr-2"></div>
                    System Healthy
                  </Badge>
                  <Badge variant="secondary">
                    24/7 Available
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 bg-gradient-secondary">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-4 text-foreground">
                Get IT Help <span className="text-primary">Instantly</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Your go to agent to help you with any workplace related tasks from getting you curated knowledge to handling tickets on our behalf , providing alerts and performing self help requests
              </p>
              
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">24/7</div>
                  <div className="text-sm text-muted-foreground">Always Available</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">&lt;1min</div>
                  <div className="text-sm text-muted-foreground">Average Response</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">97%</div>
                  <div className="text-sm text-muted-foreground">Resolution Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary mb-1">550+</div>
                  <div className="text-sm text-muted-foreground">Issues Resolved</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={heroImage} 
                alt="IT Support and Technology" 
                className="rounded-lg shadow-large w-full"
              />
              <div className="absolute inset-0 bg-gradient-primary/10 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h3 className="text-2xl font-semibold mb-2 text-foreground">Start a Conversation</h3>
              <p className="text-muted-foreground">
                Describe your IT issue and get instant help from our intelligent assistant.
              </p>
            </div>
            <ChatInterface />
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Status Card */}
            <Card className="p-6 shadow-medium">
              <h4 className="font-semibold mb-4 text-foreground flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                System Status
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Network</span>
                  <Badge variant="outline" className="border-success text-success">
                    <div className="w-2 h-2 bg-success rounded-full mr-1"></div>
                    Optimal
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Email Services</span>
                  <Badge variant="outline" className="border-success text-success">
                    <div className="w-2 h-2 bg-success rounded-full mr-1"></div>
                    Online
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">File Servers</span>
                  <Badge variant="outline" className="border-warning text-warning">
                    <div className="w-2 h-2 bg-warning rounded-full mr-1"></div>
                    Maintenance
                  </Badge>
                </div>
              </div>
            </Card>

            {/* Recent Activity */}
            <Card className="p-6 shadow-medium">
              <h4 className="font-semibold mb-4 text-foreground flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                Recent Activity
              </h4>
              <div className="space-y-3">
                <div className="text-sm">
                  <div className="font-medium text-foreground">Password reset completed</div>
                  <div className="text-muted-foreground">2 minutes ago</div>
                </div>
                <div className="text-sm">
                  <div className="font-medium text-foreground">Software update deployed</div>
                  <div className="text-muted-foreground">1 hour ago</div>
                </div>
                <div className="text-sm">
                  <div className="font-medium text-foreground">Network optimization</div>
                  <div className="text-muted-foreground">3 hours ago</div>
                </div>
              </div>
            </Card>

            {/* Agent Stats */}
            <Card className="p-6 shadow-medium">
              <h4 className="font-semibold mb-4 text-foreground flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Support Team
              </h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Available Agents</span>
                  <Badge variant="secondary">3 Online</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Queue Length</span>
                  <Badge variant="outline" className="border-success text-success">0 Waiting</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Avg. Response</span>
                  <Badge variant="outline" className="border-info text-info">
                    <Zap className="w-3 h-3 mr-1" />
                    Instant
                  </Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Quick Actions Section */}
        <div className="mt-12">
          <QuickActions />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>© 2025 TCS Workplace Companion</p>
            <p className="mt-2">You can contact Global Helpdesk, Email :<a href="mailto: Global.Helpdesk@tcs.com"> Global.Helpdesk@tcs.com</a> Contact number : <a href="tel:18002576563">18002576563</a> for India</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;